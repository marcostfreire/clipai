"""Services for video processing."""
