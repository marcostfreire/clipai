"""ClipAI Backend Application."""
__version__ = "1.0.0"
